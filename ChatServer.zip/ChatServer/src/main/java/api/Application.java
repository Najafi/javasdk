package api;

import xbank.ChatMain;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

    public static String token = "e5132fefd5a04a2a8bb27f0aa6c9d62b"; // WepodChat2
//    public static String token = "2703b296089441c2b3a018e8a9b297c5";
    public static ChatMain chatMain = new ChatMain();

    public static void main(String[] args) {

        chatMain.init();
        chatMain.setToken(token);

        SpringApplication.run(Application.class, args);


    }
}
