package api;

import java.util.Dictionary;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.*;

@RestController()
@RequestMapping("/api/chat")
public class ChatController {

	private static final String template = "Hello, %s!";
	private final AtomicLong counter = new AtomicLong();
	private String WepodChatToken = "e5132fefd5a04a2a8bb27f0aa6c9d62b"; // WepodChat2

	@RequestMapping("/greeting1")
	public Greeting greeting(@RequestParam(value="name", defaultValue="World") String name) {
		return new Greeting(counter.incrementAndGet(),
							String.format(template, name));
	}

	@RequestMapping(value = "/userToSsoIdSendMessage", method = RequestMethod.POST)
	@ResponseBody
	public UserToSsoIdMessage UserToSsoIdSendMessage(@RequestBody UserToSsoIdMessage userToSsoIdMessage) {

		Application.chatMain.setToken(userToSsoIdMessage.AccessToken);
		Application.chatMain.createThreadWithMessageForSsoId(userToSsoIdMessage.SsoId, userToSsoIdMessage.Message);
		Application.chatMain.setToken(WepodChatToken);

		return userToSsoIdMessage;
	}

	@RequestMapping(value = "/userToUsernameSendMessage", method = RequestMethod.POST)
	@ResponseBody
	public Dictionary<String, String> UserToUsernameSendMessage(@RequestBody UserToUsernameMessage userToUsernameMessage) {

		Application.chatMain.setToken(userToUsernameMessage.AccessToken);
		Dictionary<String, String> uniqueIds = Application.chatMain.createThreadWithMessageForUsername(userToUsernameMessage.Username, userToUsernameMessage.Message, userToUsernameMessage.JsonMetaData);
		Application.chatMain.setToken(WepodChatToken);

		return uniqueIds;
	}

	@RequestMapping(value = "/createGroup", method = RequestMethod.POST)
	@ResponseBody
	public String CreateGroup(@RequestBody GroupData groupData) {

		Application.chatMain.setToken(groupData.AccessToken);
		String threadId = Application.chatMain.createGroup(groupData.Title, groupData.Members, groupData.JsonMetaData);
		Application.chatMain.setToken(WepodChatToken);

		return threadId;
	}

	@RequestMapping(value = "/userToUserIdSendMessage", method = RequestMethod.POST)
	@ResponseBody
	public UserToUserIdMessage UserToUserIdSendMessage(@RequestBody UserToUserIdMessage userToSsoIdMessage) {
//		try(ChatMain chatMain = new ChatMain()){
//
//			chatMain.init(userToSsoIdMessage.AccessToken);
//
//			chatMain.createThreadWithMessageForUserId(userToSsoIdMessage.UserId, userToSsoIdMessage.Message);
//
//		} catch (IOException e) {
//			e.printStackTrace();
//		}

		return userToSsoIdMessage;
	}

	@RequestMapping(value = "/sendMessageToThread", method = RequestMethod.POST)
	@ResponseBody
	public UserToThreadMessage SendMessageToThread(@RequestBody UserToThreadMessage userToThreadMessage) {

		Application.chatMain.setToken(userToThreadMessage.AccessToken);
		Application.chatMain.sendMessageToThread(userToThreadMessage.ThreadUniqueId, userToThreadMessage.Message, userToThreadMessage.JsonMetaData);
		Application.chatMain.setToken(WepodChatToken);

		return userToThreadMessage;
	}

	@RequestMapping(value = "/replyMessage", method = RequestMethod.POST)
	@ResponseBody
	public ReplyMessage ReplyMessage(@RequestBody ReplyMessage replyMessage) {

		Application.chatMain.setToken(replyMessage.AccessToken);
		Application.chatMain.replyMessage(replyMessage.ThreadUniqueId, replyMessage.MessageUniqueId, replyMessage.Message, replyMessage.JsonMetaData);
		Application.chatMain.setToken(WepodChatToken);

		return replyMessage;
	}

	@RequestMapping(value = "/addParticipants", method = RequestMethod.POST)
    @ResponseBody
    public ParticipantsData AddParticipants(@RequestBody ParticipantsData participantsData) {

        Application.chatMain.setToken(participantsData.AccessToken);
        Application.chatMain.addParticipants(participantsData.ThreadUniqueId, participantsData.ContactIds);
        Application.chatMain.setToken(WepodChatToken);

        return participantsData;
    }

    @RequestMapping(value = "/getParticipants", method = RequestMethod.POST)
    @ResponseBody
    public ThreadUniqueIdData GetParticipants(@RequestBody ThreadUniqueIdData threadUniqueIdData) {

        Application.chatMain.setToken(threadUniqueIdData.AccessToken);
        Application.chatMain.getParticipant(threadUniqueIdData.ThreadUniqueId);
        Application.chatMain.setToken(WepodChatToken);

        return threadUniqueIdData;
    }

    @RequestMapping(value = "/editMessage", method = RequestMethod.POST)
    @ResponseBody
    public EditMessageData EditMessage(@RequestBody EditMessageData editMessageData) {

        Application.chatMain.setToken(editMessageData.AccessToken);
        Application.chatMain.editMessage(editMessageData.MessageUniqueId, editMessageData.Message, editMessageData.JsonMetaData);
        Application.chatMain.setToken(WepodChatToken);

        return editMessageData;
    }

	@RequestMapping(value = "/deleteMessage", method = RequestMethod.POST)
	@ResponseBody
	public DeleteMessageData DeleteMessage(@RequestBody DeleteMessageData deleteMessageData) {

		Application.chatMain.setToken(deleteMessageData.AccessToken);
		Application.chatMain.deleteMessage(deleteMessageData.MessageUniqueId);
		Application.chatMain.setToken(WepodChatToken);

		return deleteMessageData;
	}

	@RequestMapping(value = "/leaveThread", method = RequestMethod.POST)
	@ResponseBody
	public LeaveThreadData LeaveThread(@RequestBody LeaveThreadData leaveThreadData) {

		Application.chatMain.setToken(leaveThreadData.AccessToken);
		Application.chatMain.leaveThread(leaveThreadData.ThreadUniqueId);
		Application.chatMain.setToken(WepodChatToken);

		return leaveThreadData;
	}

	@RequestMapping(value = "/removeParticipants", method = RequestMethod.POST)
	@ResponseBody
	public RemoveParticipantsData RemoveParticipants(@RequestBody RemoveParticipantsData removeParticipantsData) {

		Application.chatMain.setToken(removeParticipantsData.AccessToken);
		Application.chatMain.removeParticipants(removeParticipantsData.ThreadUniqueId, removeParticipantsData.ParticipantIds, removeParticipantsData.TypeCode);
		Application.chatMain.setToken(WepodChatToken);

		return removeParticipantsData;
	}

	@RequestMapping(value = "/updateThreadInfo", method = RequestMethod.POST)
	@ResponseBody
	public UpdateThreadInfoData UpdateThreadInfo(@RequestBody UpdateThreadInfoData updateThreadInfoData) {

		Application.chatMain.setToken(updateThreadInfoData.AccessToken);
		Application.chatMain.updateThreadInfo(updateThreadInfoData.ThreadUniqueId, updateThreadInfoData.Name, updateThreadInfoData.Description, updateThreadInfoData.Metadata);
		Application.chatMain.setToken(WepodChatToken);

		return updateThreadInfoData;
	}

	@RequestMapping(value = "/setRole", method = RequestMethod.POST)
	@ResponseBody
	public SetRoleData SetRole(@RequestBody SetRoleData updateThreadInfoData) {

		Application.chatMain.setToken(updateThreadInfoData.AccessToken);
		Application.chatMain.setRole(updateThreadInfoData.ThreadUniqueId, updateThreadInfoData.ParticipantId);
		Application.chatMain.setToken(WepodChatToken);

		return updateThreadInfoData;
	}

	@RequestMapping(value = "/setAuditorRole", method = RequestMethod.POST)
	@ResponseBody
	public SetAuditorRoleData SetAuditorRole(@RequestBody SetAuditorRoleData setAuditorRoleData) {

		Application.chatMain.setToken(setAuditorRoleData.AccessToken);
		Application.chatMain.setAuditorRole(setAuditorRoleData.ThreadUniqueId, setAuditorRoleData.Id);
		Application.chatMain.setToken(WepodChatToken);

		return setAuditorRoleData;
	}

}
