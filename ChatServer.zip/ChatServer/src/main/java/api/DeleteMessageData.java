package api;

public class DeleteMessageData {
    public String AccessToken;
    public String MessageUniqueId;
}
