package api;

public class EditMessageData {
    public String AccessToken;
    public String MessageUniqueId;
    public String Message;
    public String JsonMetaData;
}
