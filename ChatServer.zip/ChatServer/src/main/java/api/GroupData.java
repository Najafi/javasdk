package api;

public class GroupData {
    public String AccessToken;
    public String Title;
    public String[] Members;
    public String JsonMetaData;
}
