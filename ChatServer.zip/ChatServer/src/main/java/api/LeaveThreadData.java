package api;

public class LeaveThreadData {
    public String AccessToken;
    public String ThreadUniqueId;
}
