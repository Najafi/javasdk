package api;

import java.util.List;

public class ParticipantsData {
    public String AccessToken;
    public String ThreadUniqueId;
    public List<Long> ContactIds;
}
