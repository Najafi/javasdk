package api;

import java.util.List;

public class RemoveParticipantsData {
    public String AccessToken;
    public String ThreadUniqueId;
    public List<Long> ParticipantIds;
    public String TypeCode;
}
