package api;

public class ReplyMessage {
    public String AccessToken;
    public String ThreadUniqueId;
    public String MessageUniqueId;
    public String Message;
    public String JsonMetaData;
}
