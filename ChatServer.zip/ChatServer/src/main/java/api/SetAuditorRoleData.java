package api;

public class SetAuditorRoleData {
    public String AccessToken;
    public String ThreadUniqueId;
    public long Id;
}
