package api;

public class SetRoleData {
    public String AccessToken;
    public String ThreadUniqueId;
    public long ParticipantId;
}
