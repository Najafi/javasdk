package api;

public class ThreadUniqueIdData {
    public String AccessToken;
    public String ThreadUniqueId;
}
