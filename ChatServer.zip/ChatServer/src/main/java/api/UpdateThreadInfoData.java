package api;

public class UpdateThreadInfoData {
    public String AccessToken;
    public String ThreadUniqueId;
    public String Name;
    public String Description;
    public String Metadata;
}
