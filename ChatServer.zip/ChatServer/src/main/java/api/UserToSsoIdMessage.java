package api;

public class UserToSsoIdMessage {
    public String AccessToken;
    public String SsoId;
    public String Message;
}
