package api;

public class UserToThreadMessage {
    public String AccessToken;
    public String ThreadUniqueId;
    public String Message;
    public String JsonMetaData;
}
