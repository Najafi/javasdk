package api;

public class UserToUserIdMessage {
    public String AccessToken;
    public String UserId;
    public String Message;
}
