package api;

public class UserToUsernameMessage {
    public String AccessToken;
    public String Username;
    public String Message;
    public String JsonMetaData;
}
