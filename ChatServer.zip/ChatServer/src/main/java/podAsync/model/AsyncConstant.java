package podAsync.model;


public class AsyncConstant {

    public static final String PREFERENCE = "PREFERENCE";
    public static final String PEER_ID = "PEER_ID";
    public static final String DEVICE_ID = "DEVICE_ID";
    public static final String ASYNC_STATE_OPEN = "OPEN";

}
