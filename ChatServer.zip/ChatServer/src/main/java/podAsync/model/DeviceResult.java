package podAsync.model;

import java.util.ArrayList;

public class DeviceResult {
private ArrayList<Device> devices;
    public ArrayList<Device> getDevices() {
        return devices;
    }

    public void setDevices(ArrayList<Device> devices) {
        this.devices = devices;
    }
}
