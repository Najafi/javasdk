package podChat.cachemodel.queue;


public class Failed extends Sending {

}

