package podChat.cachemodel.queue;

public class Uploading extends Sending {

}
