package podChat.cachemodel.queue;


public class UploadingQueueCache extends SendingQueueCache {

}
