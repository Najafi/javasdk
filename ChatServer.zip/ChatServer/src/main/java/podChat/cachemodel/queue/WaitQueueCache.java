package podChat.cachemodel.queue;

public class WaitQueueCache extends SendingQueueCache {

}

