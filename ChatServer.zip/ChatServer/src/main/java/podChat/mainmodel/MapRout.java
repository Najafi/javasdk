package podChat.mainmodel;

import java.util.List;

public class MapRout {
    private List<MapRoutItem> routes;

    public List<MapRoutItem> getRoutes() {
        return routes;
    }

    public void setRoutes(List<MapRoutItem> routes) {
        this.routes = routes;
    }
}
