package podChat.model;

public class OutPutInfoThread {
    private ResultThread result;

    public ResultThread getResult() {
        return result;
    }

    public void setResult(ResultThread result) {
        this.result = result;
    }
}
