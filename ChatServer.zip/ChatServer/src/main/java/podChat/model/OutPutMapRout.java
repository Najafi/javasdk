package podChat.model;


import podChat.mainmodel.MapRout;

public class OutPutMapRout extends BaseOutPut{

    private MapRout result;

    public MapRout getResult() {
        return result;
    }

    public void setResult(MapRout result) {
        this.result = result;
    }
}
