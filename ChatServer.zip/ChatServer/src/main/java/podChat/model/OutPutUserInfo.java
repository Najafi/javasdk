package podChat.model;

public class OutPutUserInfo extends BaseOutPut{

    private ResultUserInfo result;

    public ResultUserInfo getResult() {
        return result;
    }

    public void setResult(ResultUserInfo resultUserInfo) {
        this.result = resultUserInfo;
    }
}
