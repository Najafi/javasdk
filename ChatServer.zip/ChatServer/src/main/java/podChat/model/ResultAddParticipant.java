package podChat.model;


import podChat.mainmodel.Thread;

public class ResultAddParticipant {
    private Thread thread;


    public Thread getThread() {
        return thread;
    }

    public void setThread(Thread thread) {
        this.thread = thread;
    }
}
