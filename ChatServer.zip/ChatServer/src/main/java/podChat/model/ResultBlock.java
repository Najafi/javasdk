package podChat.model;

import podChat.mainmodel.Contact;

public class ResultBlock {
    private Contact contact;

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }
}
