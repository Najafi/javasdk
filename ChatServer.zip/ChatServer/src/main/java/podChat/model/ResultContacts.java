package podChat.model;


import podChat.mainmodel.Contact;

public class ResultContacts  extends Contact {

}

