package podChat.model;

public class ResultMute {
    private long threadId;

    public long getThreadId() {
        return threadId;
    }

    public void setThreadId(long threadId) {
        this.threadId = threadId;
    }
}
