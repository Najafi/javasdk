package podChat.model;

import podChat.mainmodel.MapRout;

public class ResultRoutMap {
    private MapRout routs;
}
