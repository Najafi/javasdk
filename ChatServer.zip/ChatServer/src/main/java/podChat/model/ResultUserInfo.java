package podChat.model;


import podChat.mainmodel.UserInfo;

public class ResultUserInfo {
    private UserInfo user;

    public UserInfo getUser() {
        return user;
    }

    public void setUser(UserInfo user) {
        this.user = user;
    }
}
