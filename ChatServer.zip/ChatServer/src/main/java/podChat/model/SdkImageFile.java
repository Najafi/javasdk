package podChat.model;

public class SdkImageFile {

    private FileImageMetaData file;

    public FileImageMetaData getFile() {
        return file;
    }

    public void setFile(FileImageMetaData file) {
        this.file = file;
    }
}
