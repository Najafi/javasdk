package podChat.util;

public class ChatStateType {

    public static final String CHAT_READY = "CHAT_READY";
    public static final String CONNECTING = "CONNECTING";
    public static final String CLOSING = "CLOSING";
    public static final String CLOSED = "CLOSED";
    public static final String OPEN = "OPEN";
    public static final String ASYNC_READY = "ASYNC_READY";

}
