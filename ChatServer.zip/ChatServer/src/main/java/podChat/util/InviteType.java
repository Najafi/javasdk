package podChat.util;


public class InviteType {
    public static final int TO_BE_USER_SSO_ID = 1;
    public static final int TO_BE_USER_CONTACT_ID = 2;
    public static final int TO_BE_USER_CELLPHONE_NUMBER = 3;
    public static final int TO_BE_USER_USERNAME = 4;
    public static final int TO_BE_USER_ID = 5;


}
