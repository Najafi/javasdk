package podChat.util;

public class RoleOperation {

    public static final String ADD = "add";
    public static final String REMOVE = "remove";
}
