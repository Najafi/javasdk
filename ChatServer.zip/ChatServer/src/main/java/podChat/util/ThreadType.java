package podChat.util;

public class ThreadType {
    public static final int NORMAL = 0;
    public static final int OWNER_GROUP = 1;
    public static final int PUBLIC_GROUP = 2;
    public static final int CHANNEL_GROUP = 4;
    public static final int CHANNEL = 8;

}
