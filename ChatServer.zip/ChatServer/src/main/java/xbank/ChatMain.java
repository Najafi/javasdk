package xbank;

import com.google.gson.Gson;
import exception.ConnectionException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import podAsync.Async;
import podChat.mainmodel.Invitee;
import podChat.mainmodel.MessageVO;
import podChat.mainmodel.RequestSearchContact;
import podChat.mainmodel.RequestThreadInnerMessage;
import podChat.model.*;
import podChat.requestobject.*;
import podChat.util.InviteType;
import podChat.util.RoleOperation;
import podChat.util.RoleType;
import podChat.util.ThreadType;

import java.io.*;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created By Khojasteh on 7/27/2019
 */
public class ChatMain implements ChatContract.view {
    public static String platformHost = "https://sandbox.pod.ir:8043";
    public static String token = "e5132fefd5a04a2a8bb27f0aa6c9d62b"; // WepodChat2
//    public static String token = "2703b296089441c2b3a018e8a9b297c5";
    public static String ssoHost = "https://accounts.pod.ir";
    public static String fileServer = "https://sandbox.pod.ir:8443";
    public static String serverName = "chat-server";
    public static String queueServer = "10.56.16.25";
    public static String queuePort = "61616";
    public static String queueInput = "queue-in-wepod";
    public static String queueOutput = "queue-out-wepod";
    public static String queueUserName = "root";
    public static String queuePassword = "zalzalak";
    public static ChatController chatController;
    public static ConcurrentHashMap ThreadIds = new ConcurrentHashMap();
    public static ConcurrentHashMap MessageIds = new ConcurrentHashMap();
    private static Logger logger = LogManager.getLogger(Async.class);
    Gson gson = new Gson();

    public void init() {
        chatController = new ChatController(this);
        try {

            ThreadIds = loadIds("threadIds.ser");
            MessageIds = loadIds("messageIds.ser");

            RequestConnect requestConnect = new RequestConnect
                    .Builder(queueServer,
                    queuePort,
                    queueInput,
                    queueOutput,
                    queueUserName,
                    queuePassword,
                    serverName,
                    token,
                    ssoHost,
                    platformHost,
                    fileServer,
                    4101L)
                    .build();

            chatController.connect(requestConnect);

              Thread.sleep(2000);

        } catch (ConnectionException | InterruptedException e) {
            System.out.println(e);
        }


    }


    /*********************************************************************
     *                             ADMIN                                 *
     *********************************************************************/

    /**
     * set role
     */
    public void setRole(String uniqueId ,long participantId) {

        long threadId = (long) ThreadIds.get(uniqueId);

        RequestRole requestRole = new RequestRole();
        requestRole.setId(participantId);
        requestRole.setRoleTypes(new ArrayList<String>() {{
            add(RoleType.THREAD_ADMIN);
            add(RoleType.REMOVE_USER);
        }});
        requestRole.setRoleOperation(RoleOperation.ADD);


        ArrayList<RequestRole> requestRoleArrayList = new ArrayList<>();
        requestRoleArrayList.add(requestRole);

        RequestAddRole requestAddRole = new RequestAddRole
                .Builder(threadId, requestRoleArrayList)
                .build();

        chatController.setAdmin(requestAddRole);

    }

    public void setAuditorRole(String uniqueId ,long id) {

        long threadId = (long) ThreadIds.get(uniqueId);

        RequestRole requestRole = new RequestRole();
        requestRole.setId(id);
        requestRole.setRoleTypes(new ArrayList<String>() {{
            add(RoleType.POST_CHANNEL_MESSAGE);
            add(RoleType.READ_THREAD);
        }});
        requestRole.setRoleOperation(RoleOperation.REMOVE);


        ArrayList<RequestRole> requestRoleArrayList = new ArrayList<>();
        requestRoleArrayList.add(requestRole);

        RequestAddRole requestAddRole = new RequestAddRole
                .Builder(threadId, requestRoleArrayList)
                .build();

        chatController.setAdmin(requestAddRole);

    }

    /**
     * delete role
     */
    void deleteRole() {
        RequestRole requestRole = new RequestRole();
        requestRole.setId(4781);
        requestRole.setRoleTypes(new ArrayList<String>() {{
            add(RoleType.THREAD_ADMIN);
        }});
        requestRole.setRoleOperation(RoleOperation.REMOVE);


        ArrayList<RequestRole> requestRoleArrayList = new ArrayList<>();
        requestRoleArrayList.add(requestRole);

        RequestAddRole requestAddRole = new RequestAddRole
                .Builder(5941, requestRoleArrayList)
                .build();

        chatController.setAdmin(requestAddRole);

    }


    void getAdmin() {
        RequestGetAdmin requestGetAdmin = new RequestGetAdmin
                .Builder(5941)
                .build();

        chatController.getAdminList(requestGetAdmin);
    }

    /******************************************************************
     *                           CONTACT                              *
     * ****************************************************************/

    /**
     * add contact
     */
    void addContact() {
        RequestAddContact requestAddContact = new RequestAddContact
                .Builder()
                .cellphoneNumber("09359684661")
                .lastName("شادی")
                .build();
        chatController.addContact(requestAddContact);
    }

    /**
     * remove contact
     */
    private void removeContact() {
        RequestRemoveContact requestRemoveContact = new RequestRemoveContact
                .Builder(20714)
                .build();

        chatController.removeContact(requestRemoveContact);
    }

    /**
     * update contact
     */
    private void updateContact() {
        RequestUpdateContact requestUpdateContact = new RequestUpdateContact
                .Builder(13882, "زهرا", "مظلوم", "09156452709", "zahra@gmail.com")
                .build();

        chatController.updateContact(requestUpdateContact);
    }

    /**
     * search contact
     */
    private void searchContact() {
        RequestSearchContact searchContact = new RequestSearchContact
                .Builder()
                .cellphoneNumber("09156452709")
                .build();

        chatController.searchContact(searchContact);
    }

    /**
     * get contact
     */
    private void getcontact() {
        RequestGetContact requestGetContact = new RequestGetContact
                .Builder()
                .build();
        chatController.getContact(requestGetContact);
    }

    /**
     * block
     */
    private void block() {
        RequestBlock requestBlock = new RequestBlock
                .Builder()
                .contactId(13882)
                .build();

        chatController.block(requestBlock);
    }

    /**
     * unblock
     */
    private void unblock() {
        RequestUnBlock requestUnBlock = new RequestUnBlock
                .Builder()
//                (6061)
                .blockId(2001)
                .build();

        chatController.unBlock(requestUnBlock);
    }

    /**
     * block list
     */
    private void getBlockList() {
        RequestBlockList requestBlockList = new RequestBlockList
                .Builder()
                .build();

        chatController.getBlockList(requestBlockList);
    }
    /******************************************************************
     *                           HISTORY                              *
     * ****************************************************************/

    /**
     * clear history
     */
    private void clearHistory() {
        RequestClearHistory requestClearHistory = new RequestClearHistory
                .Builder(5461)
                .build();

        chatController.clearHistory(requestClearHistory);
    }

    /**
     * get history
     */
    private void getHistory() {
    /*    RequestGetHistory requestGetHistory = new RequestGetHistory
                .Builder(5461)
                .build();

        chatController.getHistory(requestGetHistory);*/
        RequestGetHistory requestGetHistory2 = new RequestGetHistory
                .Builder(5461)
                .uniqueIds(new String[]{"a98d00af-6cb7-4174-a82a-a8ec68af0bb1"})
                .build();

        chatController.getHistory(requestGetHistory2);

     /*   RequestGetHistory requestGetHistory1 = new RequestGetHistory
                .Builder(5461)
                .build();

        chatController.getHistory(requestGetHistory1, null);*/
    }

    /******************************************************************
     *                           THREAD                               *
     * ****************************************************************/

    /**
     * Update thread
     */
    public void updateThreadInfo(String uniqueId, String name, String description, String metadata) {

        long threadId = (long) ThreadIds.get(uniqueId);

        RequestThreadInfo threadInfo = new RequestThreadInfo
                .Builder()
                .threadId(threadId)
                .name(name)
                .description(description)
                .metadata(metadata)
                .build();

        chatController.updateThreadInfo(threadInfo);
    }

    /**
     * leave thread
     */
    public void leaveThread(String uniqueId) {

        long threadId = (long) ThreadIds.get(uniqueId);

        RequestLeaveThread leaveThread = new RequestLeaveThread
                .Builder(threadId)
                .build();

        chatController.leaveThread(leaveThread);
    }

    /**
     * delete message
     */
    public void deleteMessage(String uniqueId) {

        long messageId = (long) MessageIds.get(uniqueId);

        RequestDeleteMessage deleteMessage = new RequestDeleteMessage
                .Builder(new ArrayList<Long>() {{
            add(messageId);
        }})
                .deleteForAll(true)
                .build();

        chatController.deleteMessage(deleteMessage);
    }



    /**
     * create thread with message
     */
    public void createThreadWithMessage() {
        RequestThreadInnerMessage requestThreadInnerMessage = new RequestThreadInnerMessage
                .Builder()
                .message("salam amin azizam333333.")
                .build();

//        Invitee invitee1 = new Invitee();
//        invitee1.setId("690");
//        invitee1.setIdType(InviteType.TO_BE_USER_ID);
//
//        Invitee invitee1 = new Invitee();
//        invitee1.setId(1181);
//        invitee1.setIdType(InviteType.TO_BE_USER_ID);
// 8148403

        Invitee invitee2 = new Invitee();
        invitee2.setId("8148403");
        invitee2.setIdType(InviteType.TO_BE_USER_SSO_ID);

//        Invitee invitee3 = new Invitee();
//        invitee3.setId("22178");
//        invitee3.setIdType(InviteType.TO_BE_USER_CONTACT_ID);
//
//        Invitee invitee4 = new Invitee();
//        invitee4.setId("1167562");
//        invitee4.setIdType(InviteType.TO_BE_USER_CONTACT_ID);
//
        RequestCreateThreadWithMessage requestCreateThreadWithMessage = new RequestCreateThreadWithMessage
                .Builder(ThreadType.NORMAL, new ArrayList<Invitee>() {{
//            add(invitee1);
            add(invitee2);
//            add(invitee3);
//            add(invitee4);
        }})
                .message(requestThreadInnerMessage)
                .build();

        chatController.createThreadWithMessage(requestCreateThreadWithMessage);

    }

    public void createThreadWithMessageForSsoId(String ssoId, String message) {
        RequestThreadInnerMessage requestThreadInnerMessage = new RequestThreadInnerMessage
                .Builder()
                .message(message)
                .build();


        Invitee invitee = new Invitee();
        invitee.setId(ssoId);
        invitee.setIdType(InviteType.TO_BE_USER_SSO_ID);

        RequestCreateThreadWithMessage requestCreateThreadWithMessage = new RequestCreateThreadWithMessage
                .Builder(ThreadType.NORMAL, new ArrayList<Invitee>() {{ add(invitee); }})
                .message(requestThreadInnerMessage)
                .build();

        chatController.createThreadWithMessage(requestCreateThreadWithMessage);
    }

    public Dictionary<String, String> createThreadWithMessageForUsername(String username, String message, String jsonMetaData) {
        RequestThreadInnerMessage requestThreadInnerMessage = new RequestThreadInnerMessage
                .Builder()
                .systemMetadata(jsonMetaData)
                .message(message)
                .build();


        Invitee invitee = new Invitee();
        invitee.setId(username);
        invitee.setIdType(InviteType.TO_BE_USER_USERNAME);

        RequestCreateThreadWithMessage requestCreateThreadWithMessage = new RequestCreateThreadWithMessage
                .Builder(ThreadType.NORMAL, new ArrayList<Invitee>() {{ add(invitee); }})
                .message(requestThreadInnerMessage)
                .build();

        return chatController.createThreadWithMessage(requestCreateThreadWithMessage);
    }

    public String createGroup(String title, String[] members, String jsonMetaData) {


        ArrayList<Invitee> invitees = new ArrayList<Invitee>();

        for (int i = 0; i < members.length; i++) {
            Invitee invitee = new Invitee();
            invitee.setId(members[i]);
            invitee.setIdType(InviteType.TO_BE_USER_CONTACT_ID);
            invitees.add(invitee);
        }

        RequestCreateThread requestCreateThread = new RequestCreateThread
                .Builder(ThreadType.NORMAL, invitees)
                .metadata(jsonMetaData)
                .title(title)
                .build();

        return chatController.createThread(requestCreateThread);
    }

    public void createThreadWithMessageForUserId(String userId, String message) {
        RequestThreadInnerMessage requestThreadInnerMessage = new RequestThreadInnerMessage
                .Builder()
                .message(message)
                .build();


        Invitee invitee = new Invitee();
        invitee.setId(userId);
        invitee.setIdType(InviteType.TO_BE_USER_ID);

        RequestCreateThreadWithMessage requestCreateThreadWithMessage = new RequestCreateThreadWithMessage
                .Builder(ThreadType.NORMAL, new ArrayList<Invitee>() {{ add(invitee); }})
                .message(requestThreadInnerMessage)
                .build();

        chatController.createThreadWithMessage(requestCreateThreadWithMessage);
    }

    /**
     * edit message
     */
    public void editMessage(String uniqueId, String messageContent, String metaData) {

        long messageId = (long)MessageIds.get(uniqueId);

        chatController.editMessage((int)messageId, messageContent, metaData);
    }

    /**
     * send message
     */
    private void sendMessage() {
        RequestMessage requestThread = new RequestMessage
                .Builder("seen list", 5461L)
                .build();

        chatController.sendTextMessage(requestThread);
    }

    /**
     * send thread message
     */
    public void sendMessageToThread(String uniqueId, String message, String jsonMetaData) {
        long threadId = (long) ThreadIds.get(uniqueId);
        RequestMessage requestThread = new RequestMessage
                .Builder(message, threadId)
                .jsonMetaData(jsonMetaData)
                .build();

        chatController.sendTextMessage(requestThread);
    }

    /**
     * get thread
     */
    public void getThreads() {
        RequestThread requestThread = new RequestThread
                .Builder()
                .build();

        chatController.getThreads(requestThread);
    }

    /**
     * delete multiple message
     */
    private void deleteMultipleMessage() {
        RequestDeleteMessage requestDeleteMessage = new RequestDeleteMessage
                .Builder(new ArrayList<Long>() {{
            add(56242L);
            add(56241L);
        }})
                .deleteForAll(true)
                .build();

        chatController.deleteMultipleMessage(requestDeleteMessage);
    }

    /**
     * forward message
     */
    private void forwardMessage() {
        RequestForwardMessage forwardMessage = new RequestForwardMessage
                .Builder(3022, new ArrayList<Long>() {{
            add(55202l);
            add(55201L);
        }})
                .build();

        chatController.forwardMessage(forwardMessage);
    }

    /**
     * reply message
     */
    public void replyMessage(String threadUniqueId, String messageUniqueId, String message, String metadata) {
        long threadId = (long)ThreadIds.get(threadUniqueId);
        long messageId = (long)MessageIds.get(messageUniqueId);

        RequestReplyMessage requestReplyMessage = new RequestReplyMessage
                .Builder(message, threadId, messageId)
                .systemMetaData(metadata)
                .build();

        chatController.replyMessage(requestReplyMessage);
    }

    /**
     * create thread
     */
    private void createThread() {
       /* Invitee[] invitees = new Invitee[2];
        Invitee invitee = new Invitee();
        invitee.setIdType(InviteType.TO_BE_USER_CONTACT_ID);
        invitee.setId(13812);

        Invitee invitee1 = new Invitee();
        invitee1.setIdType(InviteType.TO_BE_USER_CONTACT_ID);
        invitee1.setId(13882);

        invitees[0] = invitee;
        invitees[1] = invitee1;

        chatController.createThread(ThreadType.PUBLIC_GROUP, invitees, "sendMessage", "", "", "");*/

        Invitee[] invitees = new Invitee[1];
        Invitee invitee = new Invitee();
        invitee.setIdType(InviteType.TO_BE_USER_ID);
        invitee.setId("4101");

//        Invitee invitee2 = new Invitee();
//        invitee2.setIdType(InviteType.TO_BE_USER_CONTACT_ID);
//        invitee2.setId(13812);

        invitees[0] = invitee;
//        invitees[1] = invitee2;

        chatController.createThread(ThreadType.NORMAL, invitees, "sendMessage", "", "", "", "default");
    }

    /**
     * seen message list
     */
    private void getSeenList() {
        RequestSeenMessageList requestSeenMessageList = new RequestSeenMessageList
                .Builder(55216)
                .build();

        chatController.seenMessageList(requestSeenMessageList);
    }

    /**
     * delivery message list
     */
    private void getDeliveryList() {
        RequestDeliveredMessageList requestDeliveredMessageList = new RequestDeliveredMessageList
                .Builder(55216)
                .build();

        chatController.deliveredMessageList(requestDeliveredMessageList);
    }

    /**
     * mute thread
     */
    private void mute() {
        RequestMuteThread requestMuteThread = new RequestMuteThread
                .Builder(4982)
                .build();

        chatController.muteThread(requestMuteThread);
    }

    /**
     * unmute thread
     */
    private void unmute() {
        RequestMuteThread requestMuteThread = new RequestMuteThread
                .Builder(4982)
                .build();

        chatController.unMuteThread(requestMuteThread);
    }

    /**
     * spam thread
     */

    private void spam() {
        RequestSpam requestSpam = new RequestSpam
                .Builder(6450)
                .build();

        chatController.spam(requestSpam);
    }


    /**
     * bot message
     */

    private void interactMessage() {
        RequestInteract requestInteract = new RequestInteract
                .Builder(56249, "hello")
                .build();

        chatController.interactMessage(requestInteract);
    }

    /******************************************************************
     *                           PARTICIPANT                          *
     * ****************************************************************/

    /**
     * remove participant
     */
    public void removeParticipants(String uniqueId, List<Long> participantIds, String typeCode) {
        long threadId = (long) ThreadIds.get(uniqueId);

        RequestRemoveParticipants requestRemoveParticipants = new RequestRemoveParticipants
                .Builder(threadId, new ArrayList<Long>() {{
            for (long participantId :
                    participantIds) {
                add(participantId);
            }
        }})
                .build();

        chatController.removeParticipants(requestRemoveParticipants);
    }

    /**
     * get participant
     */
    public void getParticipant(String uniqueId) {
        long threadId = (long) ThreadIds.get(uniqueId);

        RequestThreadParticipant threadParticipant = new RequestThreadParticipant
                .Builder(threadId)
                .build();

        chatController.getThreadParticipant(threadParticipant);
    }

    /**
     * add participant
     */
    public void addParticipants(String uniqueId, List<Long> contactIds) {
        long threadId = (long) ThreadIds.get(uniqueId);
        RequestAddParticipants addParticipants = new RequestAddParticipants
                .Builder(threadId, new ArrayList<Long>() {{

            for (Long contactId : contactIds) {
                add(contactId);
            }
        }})
                .build();

        chatController.addParticipants(addParticipants);
    }

    /******************************************************************
     *                           FIlE                                 *
     * ****************************************************************/

    /**
     * send file message
     */
    private void sendFileMessage() {
        RequestFileMessage requestFileMessage = new RequestFileMessage
                .Builder(5461, "C:\\Users\\fanap-10\\Pictures\\Saved Pictures\\a.jpg")
                .description("this is test image")
                .xC(0)
                .yC(0)
                .hC(100)
                .wC(200)
                .build();

        chatController.uploadFileMessage(requestFileMessage, null);
    }

    /**
     * reply file message
     */
    private void replyFileMessage() {
  /*      RequestReplyFileMessage requestReplyFileMessage = new RequestReplyFileMessage
                .Builder("this is test", 5461, 47921, "C:\\Users\\fanap-10\\Pictures\\Saved Pictures\\a.jpg")
                .xC(0)
                .yC(0)
                .hC(100)
                .wC(200)
                .build();*/


        RequestReplyFileMessage requestReplyFileMessage = new RequestReplyFileMessage
                .Builder("this is test", 5461, 55202, "C:\\Users\\fanap_soft\\Desktop\\chat output\\b.jpg")
                .xC(0)
                .yC(0)
                .hC(100)
                .wC(200)
                .build();
        chatController.replyFileMessage(requestReplyFileMessage, null);
    }

    /**
     * upload image
     */

    private void uploadImage() {
        RequestUploadImage requestUploadImage = new RequestUploadImage
                .Builder("D:\\b.jpg")
                .build();

        chatController.uploadImage(requestUploadImage);
    }

    /**
     * upload file
     */
    private void uploadFile() {
        RequestUploadFile requestUploadFile = new RequestUploadFile
                .Builder("D:\\Music.rar")
                .build();

        chatController.uploadFile(requestUploadFile);


    }

    @Override
    public void onNewMessage(ChatResponse<ResultNewMessage> chatResponse) {
        ResultNewMessage resultNewMessage = chatResponse.getResult();
//        if (!temp) {
//            long threadId = resultNewMessage.getThreadId();
//
//            MessageVO messageVO = resultNewMessage.getMessageVO();
//
//            long messageId = messageVO.getId();
//
//            RequestReplyMessage requestReplyMessage = new RequestReplyMessage
//                    .Builder("HELLOOOO", threadId, messageId)
//                    .build();
//
//            chatController.replyMessage(requestReplyMessage, null);
//            temp = true;
//        }
        MessageIds.put(resultNewMessage.getMessageVO().getUniqueId(), resultNewMessage.getMessageVO().getId());

        saveMessageIds();
    }


    @Override
    public void onGetThreadHistory(ChatResponse<ResultHistory> history) {
        List<MessageVO> messageVOS = history.getResult().getHistory();

        for (MessageVO messageVO : messageVOS) {
            if (!messageVO.isSeen() && messageVO.getParticipant().getId() != 4101) {

                chatController.seenMessage(messageVO.getId(), messageVO.getParticipant().getId());
            }
        }

    }

    @Override
    public void onError(ErrorOutPut error) {
//        if (error.getErrorCode() == 21) {
//            Scanner myObj = new Scanner(System.in);
//            System.out.println("Enter token");
//
//            String token = myObj.nextLine();
//
//            chatController.setToke(token);
//            getThreads();
//
//        }
    }

    @Override
    public void onSearchContact(ChatResponse<ResultContact> chatResponse) {

        System.out.println(gson.toJson(chatResponse));
    }

    @Override
    public void OnInteractMessage(ChatResponse<ResultInteractMessage> chatResponse) {
        System.out.println("helllo");
    }

    @Override
    public void onGetContacts(ChatResponse<ResultContact> response) {
        System.out.println(response);
    }

    @Override
    public void onAddContact(ChatResponse<ResultAddContact> chatResponse) {
        System.out.println(gson.toJson(chatResponse));
    }

    @Override
    public void onCreateThread(ChatResponse<ResultThread> outPutThread) {
        System.out.println(gson.toJson(outPutThread));
        ThreadIds.put(outPutThread.getUniqueId(), outPutThread.getResult().getThread().getId());

        saveThreadIds();
    }

    public void setToken(String token) {
        chatController.setToken(token);
    }

    private void saveThreadIds() {
        saveIds("threadIds.ser", ThreadIds);
    }

    private void saveMessageIds() {
        saveIds("messageIds.ser", MessageIds);
    }

    private void saveIds(String path, ConcurrentHashMap<String, String> map) {
        try {
            FileOutputStream fos = new FileOutputStream(path);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(map);
            oos.close();
            fos.close();
            System.out.printf("Serialized HashMap data is saved in threadIds.ser");
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    private ConcurrentHashMap<String, String> loadIds(String path) {

        ConcurrentHashMap<String, String> map = new ConcurrentHashMap<>() ;

        try {
            File tempFile = new File(path);

            if (!tempFile.exists())
            {
                return map;
            }

            FileInputStream fis = new FileInputStream(path);
            ObjectInputStream ois = new ObjectInputStream(fis);
            map = (ConcurrentHashMap) ois.readObject();
            ois.close();
            fis.close();

            System.out.printf("DeSerialized HashMap data is saved in threadIds.ser");

        } catch (IOException | ClassNotFoundException ioe) {
            ioe.printStackTrace();
        }

        return map;
    }

}
